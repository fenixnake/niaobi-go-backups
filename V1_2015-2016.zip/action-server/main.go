package main

import (
	"action_server/auth"
	"action_server/config"
	"action_server/controller"
	"action_server/model"
	"github.com/go-martini/martini"
	"github.com/martini-contrib/binding"
	"github.com/martini-contrib/render"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"os"
)

//部署时安装图片处理库 https://github.com/DAddYE/vips
//部署时安装ffmpeg
//升级app时更改了数据结构需要给api地址加上版本号，正式发布后第二版开始

func main() {
	os.MkdirAll(config.PassionDir, os.FileMode(0775))
	os.MkdirAll(config.DateDir, os.FileMode(0775))
	os.MkdirAll(config.DataDir, os.FileMode(0775))
	os.MkdirAll(config.AvatarDir, os.FileMode(0775))
	os.MkdirAll(config.RoleDir, os.FileMode(0775))

	resumableLocks := model.ResumableLock{Locks: make(map[string]bool)}

	session := getSession()
	db := session.DB(config.MongoDBName)
	addIndex(db)

	martini.Env = martini.Prod
	m := martini.Classic()
	m.Map(resumableLocks)
	m.Use(martini.Static(config.StaticDir))
	m.Use(dbHandler(session))
	m.Use(render.Renderer(render.Options{
		IndentJSON: true,
	}))

	m.Group("/user", func(r martini.Router) {
		r.Post("/register", binding.Json(model.User{}), controller.Register)
		r.Post("/login", binding.Json(model.User{}), controller.Login)
	})

	m.Group("/user", func(r martini.Router) {
		r.Get("/myProfile", controller.MyProfile)
		r.Put("/register", binding.Json(model.RegisterDoneForm{}), controller.FinishRegister)
		r.Post("/avatar", controller.Avatar)
	}, authHandler(db))

	m.Group("/passion", func(r martini.Router) {
		r.Post("/new", binding.Json(model.Passion{}), controller.NewPassion)
		r.Post("/photo/:id", controller.PassionPhoto)
		r.Get("/list/:skip", controller.PassionList)
		r.Get("/myList/:skip", controller.MyPassionList)
		r.Get("/likeList/:skip", controller.PassionLikeList)
		r.Get("/checkLike/:id", controller.PassionLikeCheck)
		r.Put("/like/:id", controller.PassionLike)
		r.Delete("/unlike/:id", controller.PassionUnLike)
	}, authHandler(db))

	m.Group("/play", func(r martini.Router) {
		// r.Post("/photo", controller.PlayPhoto)
		// r.Post("/new", binding.Json(model.Play{}), controller.NewPlay)
		// r.Get("/list/:skip", controller.PlayList)
	}, authHandler(db))

	m.Group("/date", func(r martini.Router) {
		r.Post("/new", binding.Json(model.Date{}), controller.NewDate)
		r.Post("/photo", controller.DatePhoto)
		r.Put("/accept/:id/:uid/:oid", controller.AcceptDate)
		r.Get("/list/:skip", controller.DateList)
		r.Get("/requestList/:skip", controller.RequestList)
	}, authHandler(db))

	m.Group("/role", func(r martini.Router) {
		r.Post("/new", binding.MultipartForm(model.RoleFrom{}), controller.NewRole)
		r.Get("/list", controller.RoleList)
		r.Delete("/delete/:id", controller.DeleteRole)
	}, authHandler(db))

	m.Group("/vlog", func(r martini.Router) {
		r.Post("/upload", binding.MultipartForm(model.VlogInfo{}), authHandler(db), controller.UploadNew)
		r.Get("/upload/:id", controller.CheckChunk)
		r.Patch("/upload/:id", binding.MultipartForm(model.VlogChunk{}), controller.UploadChunk)
		r.Put("/upload/:id", binding.MultipartForm(model.VlogHeader{}), authHandler(db), controller.UploadHeader)

		r.Get("/draftList", authHandler(db), controller.DraftList)
		r.Delete("/draftDelete/:id", authHandler(db), controller.DeleteDraft)
		r.Post("/publish/:id", binding.Json(model.Vlog{}), authHandler(db), controller.Publish)

		r.Get("/listBySid/:sid/:skip", controller.FilmListBySid)
	})

	m.RunOnAddr(":7236")
}

func getSession() *mgo.Session {
	session, err := mgo.Dial(config.MongoDBAddr)
	if err != nil {
		panic(err)
	}
	session.SetMode(mgo.Monotonic, true)
	return session
}

func addIndex(db *mgo.Database) {
	//user index
	index := mgo.Index{
		Key:        []string{"phone", "pwd"},
		Unique:     true,
		DropDups:   true,
		Background: true,
	}
	indexErr := db.C("user").EnsureIndex(index)
	if indexErr != nil {
		panic(indexErr)
	}
}

//martini middleware
func dbHandler(session *mgo.Session) martini.Handler {
	return func(c martini.Context) {
		s := session.Clone()
		c.Map(s.DB(config.MongoDBName))
		defer s.Close()
		c.Next()
	}
}

func authHandler(db *mgo.Database) martini.Handler {
	return auth.BasicFunc(func(username, password string) model.User {
		//auth头的手机号格式都为E164 eg.+8618612345678
		u := model.User{}
		db.C("user").Find(bson.M{"phone": username, "pwd": password}).One(&u)
		return u
	})
}
