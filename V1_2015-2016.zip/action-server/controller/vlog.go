package controller

import (
	"action_server/config"
	"action_server/errs"
	"action_server/model"
	"action_server/resumable"
	"fmt"
	"github.com/go-martini/martini"
	"github.com/martini-contrib/render"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io/ioutil"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"time"
)

const (
	FilmListPageNum = 20
	DraftListMaxNum = 50
)

func DraftList(res http.ResponseWriter, user model.User, r render.Render, db *mgo.Database) {
	vlogDraftList := []model.Draft{}
	err := db.C("vlog").Find(bson.M{"owner._id": user.Id, "showed": false}).Select(bson.M{"_id": 1, "fileId": 1, "createdAt": 1}).Limit(DraftListMaxNum).Sort("-createdAt").All(&vlogDraftList)
	errs.Check400(res, err, errs.E1000)
	r.JSON(http.StatusOK, vlogDraftList)
}

func DeleteDraft(res http.ResponseWriter, params martini.Params, db *mgo.Database, c martini.Context) {
	vid := params["id"]
	if err := db.C("vlog").RemoveId(bson.ObjectIdHex(vid)); err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	res.WriteHeader(http.StatusOK)

	c.Next()

	os.Remove(getMp4Path(vid))
	os.Remove(getThumbPath(vid))
}

func Publish(res http.ResponseWriter, params martini.Params, vlog model.Vlog, user model.User, db *mgo.Database) {
	vid := bson.ObjectIdHex(params["id"])

	err := db.C("vlog").Update(bson.M{"_id": vid}, bson.M{"$set": bson.M{"showed": true, "script": vlog.Script, "sid": vlog.ScriptId}})
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	db.C("passion").Update(bson.M{"_id": vlog.ScriptId}, bson.M{"$set": bson.M{"updateAt": time.Now().Unix()}})

	res.WriteHeader(http.StatusOK)
}

func FilmListBySid(res http.ResponseWriter, params martini.Params, r render.Render, db *mgo.Database) {
	skip, _ := strconv.Atoi(params["skip"])
	sid := bson.ObjectIdHex(params["sid"])

	filmList := []model.Vlog{}
	err := db.C("vlog").Find(bson.M{"showed": true, "sid": sid}).Skip(skip).Limit(FilmListPageNum).Sort("-createdAt").All(&filmList)
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	returnSkip := skip + FilmListPageNum
	if len(filmList) < FilmListPageNum {
		returnSkip = -1
	}

	fl := model.FilmList{}
	fl.List = filmList
	fl.Skip = returnSkip

	r.JSON(http.StatusOK, fl)
}

func UploadNew(res http.ResponseWriter, info model.VlogInfo, user model.User, r render.Render, db *mgo.Database) {
	id := bson.NewObjectId().Hex()
	videoInfo := model.FileInfo{}
	videoInfo.FileName = info.FileName
	videoInfo.FileType = "mov"
	videoInfo.Offset = 0
	videoInfo.Id = id
	videoInfo.Succeed = false
	err := resumable.NewUpload(videoInfo)
	errs.Check400(res, err, errs.E2000)

	audioInfo := model.FileInfo{}
	audioInfo.FileName = info.FileName
	audioInfo.FileType = "aac"
	audioInfo.Offset = 0
	audioInfo.Id = id + "_aac"
	audioInfo.Succeed = false
	err = resumable.NewUpload(audioInfo)
	errs.Check400(res, err, errs.E2000)

	res.Header().Set("Vlog-Id", id)
	res.WriteHeader(http.StatusCreated)
}

func CheckChunk(res http.ResponseWriter, params martini.Params, r render.Render) {
	id := params["id"]

	vInfo, err := resumable.GetInfo(id)
	if err != nil {
		http.Error(res, errs.E2001, http.StatusNoContent)
		return
	}
	aInfo, err := resumable.GetInfo(id + "_aac")
	if err != nil {
		http.Error(res, errs.E2001, http.StatusNoContent)
		return
	}

	info := model.VlogInfo{}
	info.FileName = vInfo.FileName
	info.VideoOffset = vInfo.Offset
	info.IsVideoDone = vInfo.Succeed
	info.AudioOffset = aInfo.Offset
	info.IsAudioDone = aInfo.Succeed

	r.JSON(http.StatusOK, info)
}

func UploadChunk(res http.ResponseWriter, req *http.Request, params martini.Params, chunkForm model.VlogChunk, resumableLocks model.ResumableLock, r render.Render) {
	vid := params["id"]
	aid := vid + "_aac"
	videoOrAudio, _ := strconv.ParseInt(req.Header.Get("Video-Or-Audio"), 10, 64) //0:all 1:only video 2:only audio

	// Chunk大小不超过56KB(视频)＋8KB(音频)
	if err := req.ParseMultipartForm(config.MaxChunkSize); err != nil {
		errs.Check400(res, err, errs.E2002)
		return
	}

	// Ensure file is not locked
	if resumableLocks.Locks[vid] == true || resumableLocks.Locks[aid] == true {
		http.Error(res, errs.E2003, 423)
		return
	}

	// Lock file for further writes (get are allowed)
	if videoOrAudio == 0 || videoOrAudio == 1 {
		resumableLocks.Locks[vid] = true
		// File will be unlocked regardless of an error or success
		defer func() {
			delete(resumableLocks.Locks, vid)
		}()
		// 写视频文件
		videoChunk, err := chunkForm.VideoChunk.Open()
		errs.Check400(res, err, errs.E2000)
		vInfo, err := resumable.GetInfo(vid)
		errs.Check400(res, err, errs.E2000)
		bytesWritten, err := resumable.WriteChunk(vid, vInfo.Offset, videoChunk)
		res.Header().Set("Upload-Video-Offset", strconv.FormatInt(vInfo.Offset+bytesWritten, 10))
		if videoOrAudio == 1 {
			aInfo, err := resumable.GetInfo(aid)
			errs.Check400(res, err, errs.E2000)
			res.Header().Set("Upload-Audio-Offset", strconv.FormatInt(aInfo.Offset, 10))
		}
	}
	if videoOrAudio == 0 || videoOrAudio == 2 {
		resumableLocks.Locks[aid] = true
		// File will be unlocked regardless of an error or success
		defer func() {
			delete(resumableLocks.Locks, aid)
		}()
		// 写音频文件
		audioChunk, err := chunkForm.AudioChunk.Open()
		errs.Check400(res, err, errs.E2000)
		aInfo, err := resumable.GetInfo(aid)
		errs.Check400(res, err, errs.E2000)
		bytesWritten, err := resumable.WriteChunk(aid, aInfo.Offset, audioChunk)
		res.Header().Set("Upload-Audio-Offset", strconv.FormatInt(aInfo.Offset+bytesWritten, 10))
		if videoOrAudio == 2 {
			vInfo, err := resumable.GetInfo(vid)
			errs.Check400(res, err, errs.E2000)
			res.Header().Set("Upload-Video-Offset", strconv.FormatInt(vInfo.Offset, 10))
		}
	}

	res.WriteHeader(http.StatusOK)
}

func UploadHeader(res http.ResponseWriter, req *http.Request, params martini.Params, c martini.Context, headerForm model.VlogHeader, resumableLocks model.ResumableLock, user model.User, db *mgo.Database, r render.Render) {
	vid := params["id"]
	aid := vid + "_aac"
	isMerge, _ := strconv.ParseBool(req.Header.Get("Is-Merge"))
	offset, _ := strconv.ParseInt(req.Header.Get("Upload-Offset"), 10, 64)
	videoOrAudio, _ := strconv.ParseInt(req.Header.Get("Video-Or-Audio"), 10, 64) //1:video 2:audio

	id := vid
	if videoOrAudio == 2 {
		id = aid
	}

	// header大小不超过128字节
	err := req.ParseMultipartForm(config.MaxHeaderSize)
	errs.Check400(res, err, errs.E2002)

	// Ensure file is not locked
	if resumableLocks.Locks[id] == true {
		http.Error(res, errs.E2003, 423)
		return
	}

	// Lock file for further writes (get are allowed)
	resumableLocks.Locks[id] = true

	// File will be unlocked regardless of an error or success
	defer func() {
		delete(resumableLocks.Locks, id)
	}()

	info, err := resumable.GetInfo(id)
	errs.Check400(res, err, errs.E2000)

	if offset != info.Offset {
		errs.Check400(res, err, errs.E2004)
	}

	// 写文件
	header, err := headerForm.Header.Open()
	errs.Check400(res, err, errs.E2000)
	err = resumable.WriteHeader(id, header)
	errs.Check400(res, err, errs.E2000)

	//---------合并文件---------
	vInfo, err := resumable.GetInfo(vid)
	errs.Check400(res, err, errs.E2002)
	aInfo, err := resumable.GetInfo(aid)
	errs.Check400(res, err, errs.E2002)
	videoPath := getBinPath(vid)
	audioPath := getBinPath(aid)
	if vInfo.Succeed && aInfo.Succeed {
		//接收图片
		imgPath := fmt.Sprintf("%s/%s.jpg", config.DataDir, vid) // 原始大小720x404 or 720x540
		file, err := headerForm.Thumb.Open()
		errs.Check400(res, err, errs.E1000)
		inBuf, err := ioutil.ReadAll(file)
		errs.Check400(res, err, errs.E2000)
		err = ioutil.WriteFile(imgPath, inBuf, os.ModePerm)
		errs.Check400(res, err, errs.E2000)

		//接收视频
		newPath := getMp4Path(vid)
		//先移除可能有的坏文件
		os.Remove(newPath)
		if isMerge {
			// ffmpeg -i /Desktop/recordTest.bin -i /Desktop/IMG_6979.bin -c:v copy newvideo.mp4
			cmd := exec.Command("ffmpeg", "-i", videoPath, "-i", audioPath, "-c:v", "copy", newPath)
			err = cmd.Run()
			if err != nil {
				errs.Check400(res, err, errs.E2000)
				return
			}
		} else {
			err = resumable.CopyFile(videoPath, newPath)
			if err != nil {
				errs.Check400(res, err, errs.E2000)
				return
			}
		}

		//保存到数据库
		vlog := model.Vlog{}
		vlog.Id = bson.ObjectIdHex(vInfo.Id)
		vlog.CreatedAt = time.Now()
		vlog.FileId = vid
		owner := model.VlogOwner{}
		owner.Id = user.Id
		vlog.Owner = owner
		vlog.Showed = false
		vlog.Views = 0
		vlog.Length = headerForm.Length
		if headerForm.Script != "" {
			vlog.Showed = true
			vlog.Script = headerForm.Script
		}

		//新建vlog，插入数据库
		if err = db.C("vlog").Insert(vlog); err != nil {
			if mgo.IsDup(err) {
				http.Error(res, errs.E2005, 205)
			} else {
				http.Error(res, err.Error(), http.StatusInternalServerError)
			}
		} else {
			r.JSON(http.StatusCreated, vlog)

			c.Next()

			os.Remove(videoPath)
			os.Remove(audioPath)
			os.Remove(getInfoPath(vid))
			os.Remove(getInfoPath(aid))
		}
	} else {
		res.WriteHeader(http.StatusCreated)
	}
}

func getBinPath(id string) string {
	return config.DataDir + "/" + id + ".bin"
}

func getInfoPath(id string) string {
	return config.DataDir + "/" + id + ".info"
}

func getMp4Path(id string) string {
	return config.DataDir + "/" + id + ".mp4"
}

func getThumbPath(id string) string {
	return config.DataDir + "/" + id + ".jpg"
}

/**
//截图
//ffmpeg -ss 1 -t 1 -i test.mp4 -s 352x240 -y -f mjpeg test1.jpg
thumbPath := getThumbPath(vid)
cmd := exec.Command("ffmpeg", "-ss", "0.1", "-t", "1", "-i", videoPath, "-y", "-f", "mjpeg", thumbPath)
err = cmd.Run()
errs.Check400(res, err, errs.E2000)
*/
