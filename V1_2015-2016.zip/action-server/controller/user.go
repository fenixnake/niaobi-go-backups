package controller

import (
	"action_server/config"
	"action_server/errs"
	"action_server/model"
	"action_server/uid"
	"fmt"
	"github.com/daddye/vips"
	"github.com/martini-contrib/render"
	"github.com/ttacon/libphonenumber"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"time"
)

const (
	MaxAvatar     = 5 * 1024 * 1024 //上传头像最大5MB
	Avatar960x960 = "960x960"       //头像缩略图 e.g. http://localhost:3000/avatar/89d171a133a91a88c2f2b6db4c5ef27c_750x750.jpg
	Avatar750x750 = "750x750"
	Avatar100x100 = "100x100"
)

func Register(res http.ResponseWriter, user model.User, r render.Render, db *mgo.Database) {
	//处理手机号
	num, err := libphonenumber.Parse(user.Phone, user.PhoneCC)
	errs.Check400(res, err, errs.E1001)
	//auth头的手机号格式都为E164 eg.+8618612345678
	formattedNum := libphonenumber.Format(num, libphonenumber.E164)
	user.Phone = formattedNum

	//处理用户信息
	user.Id = bson.NewObjectId()
	user.CreatedAt = time.Now()
	user.Name = strconv.FormatInt(time.Now().Unix(), 10)
	user.Role = "no one"

	//新建用户，插入数据库
	if err := db.C("user").Insert(user); err != nil {
		if mgo.IsDup(err) {
			http.Error(res, errs.E1002, http.StatusBadRequest)
		} else {
			http.Error(res, err.Error(), http.StatusInternalServerError)
		}
		return
	}

	r.JSON(http.StatusCreated, user)
}

func Login(res http.ResponseWriter, user model.User, r render.Render, db *mgo.Database) {
	//处理手机号
	num, err := libphonenumber.Parse(user.Phone, user.PhoneCC)
	errs.Check400(res, err, errs.E1001)
	formattedNum := libphonenumber.Format(num, libphonenumber.E164)

	u := model.User{}
	err = db.C("user").Find(bson.M{"phone": formattedNum}).One(&u)
	errs.Check400(res, err, errs.E1005)
	if u.Pwd != user.Pwd {
		http.Error(res, errs.E1006, http.StatusBadRequest)
		return
	}

	r.JSON(http.StatusOK, u)
}

func Avatar(res http.ResponseWriter, req *http.Request, user model.User, r render.Render, db *mgo.Database) {
	user.Avatar = uid.Uid()

	if err := req.ParseMultipartForm(MaxAvatar); err != nil {
		errs.Check400(res, err, errs.E1004)
	}

	avatarDir := fmt.Sprintf("%s/%s", config.AvatarDir, user.Avatar)
	path := fmt.Sprintf("%s.jpg", avatarDir)
	toPath := fmt.Sprintf("%s_%s.jpg", avatarDir, Avatar960x960)
	toPath2 := fmt.Sprintf("%s_%s.jpg", avatarDir, Avatar750x750)
	toPath3 := fmt.Sprintf("%s_%s.jpg", avatarDir, Avatar100x100)

	for _, fileHeaders := range req.MultipartForm.File {
		for _, fileHeader := range fileHeaders {
			// original image
			file, err := fileHeader.Open()
			errs.Check400(res, err, errs.E1000)
			inBuf, err := ioutil.ReadAll(file)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(path, inBuf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)

			// thumbnail 750x750
			options := vips.Options{
				Width:        750,
				Height:       750,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err := vips.Resize(inBuf, options)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(toPath2, buf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)

			// thumbnail 100x100
			options = vips.Options{
				Width:        100,
				Height:       100,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err = vips.Resize(inBuf, options)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(toPath3, buf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)

			break
		}
	}

	err := os.Rename(path, toPath)
	errs.Check400(res, err, errs.E1000)

	//update avatar
	err = db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"avatar": user.Avatar}})
	errs.Check400(res, err, errs.E1000)

	r.JSON(http.StatusOK, user)
}

func FinishRegister(res http.ResponseWriter, req *http.Request, user model.User, updateInfo model.RegisterDoneForm, r render.Render, db *mgo.Database) {
	email := updateInfo.Email
	role := updateInfo.Role

	err := db.C("user").Update(bson.M{"_id": user.Id}, bson.M{"$set": bson.M{"role": role, "email": email}})
	errs.Check400(res, err, errs.E1000)

	user.Email = email
	user.Role = role

	r.JSON(http.StatusOK, user)
}

func MyProfile(user model.User, r render.Render, db *mgo.Database) {
	profile := model.MyProfile{}
	profile.User = user

	m1 := bson.M{"owner": bson.M{"_id": user.Id}}
	m2 := bson.M{"sender": bson.M{"_id": user.Id}}

	if user.HasNewDate {
		dateNum, _ := db.C("date").Find(bson.M{"isAccept": true, "$or": []bson.M{m1, m2}}).Count()
		profile.UnReadDate = dateNum - user.ReadDate
	} else {
		profile.UnReadDate = 0
	}

	if user.HasNewRequest {
		requestNum, _ := db.C("date").Find(bson.M{"isAccept": false, "$or": []bson.M{m1, m2}}).Count()
		profile.UnReadRequest = requestNum - user.ReadRequest
	} else {
		profile.UnReadRequest = 0
	}

	r.JSON(http.StatusOK, profile)
}
