package controller

import (
	"action_server/config"
	"action_server/errs"
	"action_server/model"
	"action_server/uid"
	"fmt"
	"github.com/daddye/vips"
	"github.com/go-martini/martini"
	"github.com/martini-contrib/render"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"time"
)

const (
	PassionListPageNum = 15
)

const (
	PassionMaxPhoto  = 5 * 1024 * 1024 //上传头像最大5MB
	PassionPhoto1024 = "1024x1024"     //头像缩略图 e.g. http://localhost:3000/passion/89d171a133a91a88c2f2b6db4c5ef27c_750x750.jpg
	PassionPhoto750  = "750x750"
)

func NewPassion(res http.ResponseWriter, req *http.Request, user model.User, passion model.Passion, r render.Render, db *mgo.Database) {
	passion.Id = bson.NewObjectId()
	passion.UpdateAt = time.Now().Unix()
	passion.CreatedAt = time.Now()
	owner := model.PassionOwner{}
	owner.Id = user.Id
	passion.Owner = owner

	//新建post，插入数据库
	err := db.C("passion").Insert(passion)
	errs.Check400(res, err, errs.E1000)

	r.JSON(http.StatusCreated, passion)
}

func PassionPhoto(res http.ResponseWriter, req *http.Request, params martini.Params, r render.Render, db *mgo.Database) {
	photoId := uid.Uid()

	if err := req.ParseMultipartForm(PassionMaxPhoto); err != nil {
		errs.Check400(res, err, errs.E1004)
	}

	passionDir := fmt.Sprintf("%s/%s", config.PassionDir, photoId)
	path := fmt.Sprintf("%s.jpg", passionDir)
	toPath750 := fmt.Sprintf("%s_%s.jpg", passionDir, PassionPhoto750)
	toPath1024 := fmt.Sprintf("%s_%s.jpg", passionDir, PassionPhoto1024)

	for _, fileHeaders := range req.MultipartForm.File {
		for _, fileHeader := range fileHeaders {
			// original image
			file, err := fileHeader.Open()
			errs.Check400(res, err, errs.E1000)
			inBuf, err := ioutil.ReadAll(file)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(path, inBuf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)

			// thumbnail 750x750
			options := vips.Options{
				Width:        750,
				Height:       750,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err := vips.Resize(inBuf, options)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(toPath750, buf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)
			break
		}
	}

	err := os.Rename(path, toPath1024)
	errs.Check400(res, err, errs.E1000)

	//update photo
	err = db.C("passion").Update(bson.M{"_id": bson.ObjectIdHex(params["id"])}, bson.M{"$set": bson.M{"photo": photoId}})
	errs.Check400(res, err, errs.E1000)

	res.WriteHeader(http.StatusOK)
}

func PassionList(res http.ResponseWriter, params martini.Params, r render.Render, db *mgo.Database) {
	skip, _ := strconv.Atoi(params["skip"])

	passionList := []model.Passion{}
	newPassionList := []model.Passion{}
	err := db.C("passion").Find(nil).Skip(skip).Limit(PassionListPageNum).Sort("-updateAt").All(&passionList)
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}
	for _, p := range passionList {
		u := model.User{}
		err := db.C("user").FindId(p.Owner.Id).Select(bson.M{"avatar": 1, "role": 1}).One(&u)
		if err != nil {
			continue
		}
		p.Owner.Avatar = u.Avatar
		p.Owner.Role = u.Role
		newPassionList = append(newPassionList, p)
	}

	returnSkip := skip + PassionListPageNum
	if len(newPassionList) < PassionListPageNum {
		returnSkip = -1
	}

	pl := model.PassionList{}
	pl.List = newPassionList
	pl.Skip = returnSkip

	r.JSON(http.StatusOK, pl)
}

func MyPassionList(res http.ResponseWriter, params martini.Params, user model.User, r render.Render, db *mgo.Database) {
	skip, _ := strconv.Atoi(params["skip"])

	passionList := []model.Passion{}
	newPassionList := []model.Passion{}
	err := db.C("passion").Find(bson.M{"owner._id": user.Id}).Skip(skip).Limit(PassionListPageNum).Sort("-updateAt").All(&passionList)
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}
	for _, p := range passionList {
		p.Owner.Avatar = user.Avatar
		p.Owner.Role = user.Role
		newPassionList = append(newPassionList, p)
	}

	returnSkip := skip + PassionListPageNum
	if len(newPassionList) < PassionListPageNum {
		returnSkip = -1
	}

	pl := model.PassionList{}
	pl.List = newPassionList
	pl.Skip = returnSkip

	r.JSON(http.StatusOK, pl)
}

func PassionLikeList(res http.ResponseWriter, params martini.Params, user model.User, r render.Render, db *mgo.Database) {
	skip, _ := strconv.Atoi(params["skip"])

	likeList := []model.Likes{}
	err := db.C("likes").Find(bson.M{"uid": user.Id}).Select(bson.M{"sid": 1, "createdAt": 1}).Skip(skip).Limit(PassionListPageNum).Sort("-createdAt").All(&likeList)
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	newPassionList := []model.Passion{}
	for _, like := range likeList {
		//剧本
		passion := model.Passion{}
		err := db.C("passion").FindId(like.ScriptId).One(&passion)
		if err != nil {
			continue
		}
		//用户头像
		u := model.User{}
		err = db.C("user").FindId(passion.Owner.Id).Select(bson.M{"avatar": 1, "role": 1}).One(&u)
		if err != nil {
			continue
		}
		passion.Owner.Avatar = u.Avatar
		passion.Owner.Role = u.Role

		newPassionList = append(newPassionList, passion)
	}

	returnSkip := skip + PassionListPageNum
	if len(newPassionList) < PassionListPageNum {
		returnSkip = -1
	}

	pl := model.PassionList{}
	pl.List = newPassionList
	pl.Skip = returnSkip

	r.JSON(http.StatusOK, pl)
}

func PassionLikeCheck(res http.ResponseWriter, user model.User, params martini.Params, db *mgo.Database, c martini.Context) {
	sid := bson.ObjectIdHex(params["id"])

	count, err := db.C("likes").Find(bson.M{"uid": user.Id, "sid": sid}).Count()
	errs.Check400(res, err, errs.E1000)
	if count > 0 {
		//已喜欢
		res.Header().Set("Like", "1")
	} else {
		//未喜欢
		res.Header().Set("Like", "0")
	}
	res.WriteHeader(http.StatusOK)

	c.Next()

	//观看数
	db.C("passion").UpdateId(sid, bson.M{"$inc": bson.M{"views": +1}})
}

func PassionLike(res http.ResponseWriter, user model.User, params martini.Params, db *mgo.Database) {
	sid := bson.ObjectIdHex(params["id"])

	count, _ := db.C("likes").Find(bson.M{"uid": user.Id, "sid": sid}).Count()
	if count == 0 {
		//插入likes表
		likes := model.Likes{}
		likes.Id = bson.NewObjectId()
		likes.UserId = user.Id
		likes.ScriptId = sid
		likes.CreatedAt = time.Now()
		err := db.C("likes").Insert(likes)
		errs.Check400(res, err, errs.E1000)

		//剧本表 喜欢数＋1
		err = db.C("passion").UpdateId(sid, bson.M{"$inc": bson.M{"likes": +1}})
		//用户表 喜欢的剧本数＋1
		err = db.C("user").UpdateId(user.Id, bson.M{"$inc": bson.M{"likes": +1}})
		errs.Check400(res, err, errs.E1000)

		res.WriteHeader(http.StatusOK)
	} else {
		//已经喜欢过了
		http.Error(res, errs.E1008, http.StatusBadRequest)
	}
}

func PassionUnLike(res http.ResponseWriter, user model.User, params martini.Params, db *mgo.Database) {
	sid := bson.ObjectIdHex(params["id"])

	count, _ := db.C("likes").Find(bson.M{"uid": user.Id, "sid": sid}).Count()
	if count > 0 {
		//likes
		likes := model.Likes{}
		err := db.C("likes").Find(bson.M{"uid": user.Id, "sid": sid}).One(&likes)
		errs.Check400(res, err, errs.E1000)

		if likes.UserId == user.Id {
			err := db.C("likes").RemoveId(likes.Id)
			errs.Check400(res, err, errs.E1000)

			//剧本表 喜欢数－1
			err = db.C("passion").UpdateId(sid, bson.M{"$inc": bson.M{"likes": -1}})
			//用户表 喜欢的剧本数－1
			err = db.C("user").UpdateId(user.Id, bson.M{"$inc": bson.M{"likes": -1}})
			errs.Check400(res, err, errs.E1000)
		} else {
			//not authorized
			http.Error(res, errs.E1003, http.StatusBadRequest)
		}
	}

	res.WriteHeader(http.StatusOK)
}
