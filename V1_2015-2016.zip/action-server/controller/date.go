package controller

import (
	"action_server/config"
	"action_server/errs"
	"action_server/model"
	"action_server/uid"
	"fmt"
	"github.com/daddye/vips"
	"github.com/go-martini/martini"
	"github.com/martini-contrib/render"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"time"
)

const (
	DateListPageNum = 15
)

const (
	DateMaxPhoto = 5 * 1024 * 1024 //上传最大5MB
	DatePhoto960 = "960x960"       //缩略图 e.g. http://localhost:3000/date/89d171a133a91a88c2f2b6db4c5ef27c_960x960.jpg
	DatePhoto750 = "750x750"
)

func DatePhoto(res http.ResponseWriter, req *http.Request, r render.Render, db *mgo.Database) {
	photoId := uid.Uid()

	if err := req.ParseMultipartForm(DateMaxPhoto); err != nil {
		errs.Check400(res, err, errs.E1004)
		return
	}

	dateDir := fmt.Sprintf("%s/%s", config.DateDir, photoId)
	path := fmt.Sprintf("%s.jpg", dateDir)
	toPath750 := fmt.Sprintf("%s_%s.jpg", dateDir, DatePhoto750)
	toPath960 := fmt.Sprintf("%s_%s.jpg", dateDir, DatePhoto960)

	for _, fileHeaders := range req.MultipartForm.File {
		for _, fileHeader := range fileHeaders {
			// original image
			file, err := fileHeader.Open()
			errs.Check400(res, err, errs.E1000)
			inBuf, err := ioutil.ReadAll(file)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(path, inBuf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)

			// thumbnail 750x750
			options := vips.Options{
				Width:        750,
				Height:       750,
				Crop:         true,
				Extend:       vips.EXTEND_WHITE,
				Interpolator: vips.BILINEAR,
				Gravity:      vips.CENTRE,
				Quality:      100,
			}
			buf, err := vips.Resize(inBuf, options)
			errs.Check400(res, err, errs.E1000)
			err = ioutil.WriteFile(toPath750, buf, os.ModePerm)
			errs.Check400(res, err, errs.E1000)
			break
		}
	}

	err := os.Rename(path, toPath960)
	errs.Check400(res, err, errs.E1000)

	r.JSON(http.StatusCreated, map[string]string{"photoId": photoId})
}

func NewDate(res http.ResponseWriter, user model.User, date model.Date, r render.Render, db *mgo.Database, c martini.Context) {
	date.Id = bson.NewObjectId()
	date.Sender.Id = user.Id
	date.IsAccept = false
	date.IsDelete = false
	date.CreatedAt = time.Now()

	if err := db.C("date").Insert(date); err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	r.JSON(http.StatusCreated, date)
	c.Next()

	db.C("user").UpdateId(date.Owner.Id, bson.M{"$set": bson.M{"hasNewRequest": true}})
}

func AcceptDate(res http.ResponseWriter, params martini.Params, db *mgo.Database, c martini.Context) {
	err := db.C("date").UpdateId(bson.ObjectIdHex(params["id"]), bson.M{"$set": bson.M{"isAccept": true}})
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	res.WriteHeader(http.StatusOK)
	c.Next()

	db.C("user").UpdateId(bson.ObjectIdHex(params["uid"]), bson.M{"$set": bson.M{"hasNewDate": true}})
	db.C("user").UpdateId(bson.ObjectIdHex(params["oid"]), bson.M{"$set": bson.M{"hasNewDate": true}})
}

func DateList(c martini.Context, res http.ResponseWriter, params martini.Params, user model.User, r render.Render, db *mgo.Database) {
	getDateList(c, res, params, user, r, db, true)
}

func RequestList(c martini.Context, res http.ResponseWriter, params martini.Params, user model.User, r render.Render, db *mgo.Database) {
	getDateList(c, res, params, user, r, db, false)
}

func getDateList(c martini.Context, res http.ResponseWriter, params martini.Params, user model.User, r render.Render, db *mgo.Database, isAccept bool) {
	skip, _ := strconv.Atoi(params["skip"])

	dateList := []model.Date{}
	newDateList := []model.Date{}
	m1 := bson.M{"owner": bson.M{"_id": user.Id}}
	m2 := bson.M{"sender": bson.M{"_id": user.Id}}
	m := bson.M{"isAccept": isAccept, "isDelete": false, "$or": []bson.M{m1, m2}}
	err := db.C("date").Find(m).Skip(skip).Limit(DateListPageNum).Sort("-createdAt").All(&dateList)
	if err != nil {
		errs.Check400(res, err, errs.E1000)
		return
	}

	for _, d := range dateList {
		u := model.User{}
		if d.Owner.Id == user.Id {
			if err := db.C("user").FindId(d.Sender.Id).Select(bson.M{"phone": 1, "phoneCC": 1, "avatar": 1, "role": 1}).One(&u); err != nil {
				continue
			}
			d.Sender.Phone = u.Phone
			d.Sender.PhoneCC = u.PhoneCC
			d.Sender.Avatar = u.Avatar
			d.Sender.Role = u.Role

			d.Owner.Phone = user.Phone
			d.Owner.PhoneCC = user.PhoneCC
			d.Owner.Avatar = user.Avatar
			d.Owner.Role = user.Role
		} else {
			if err := db.C("user").FindId(d.Owner.Id).Select(bson.M{"phone": 1, "phoneCC": 1, "avatar": 1, "role": 1}).One(&u); err != nil {
				continue
			}
			d.Sender.Phone = user.Phone
			d.Sender.PhoneCC = user.PhoneCC
			d.Sender.Avatar = user.Avatar
			d.Sender.Role = user.Role

			d.Owner.Phone = u.Phone
			d.Owner.PhoneCC = u.PhoneCC
			d.Owner.Avatar = u.Avatar
			d.Owner.Role = u.Role
		}

		newDateList = append(newDateList, d)
	}

	returnSkip := skip + DateListPageNum
	if len(newDateList) < DateListPageNum {
		returnSkip = -1
	}

	dl := model.DateList{}
	dl.List = newDateList
	dl.Skip = returnSkip

	r.JSON(http.StatusOK, dl)
	c.Next()

	//更新已读数
	if isAccept == true {
		if user.HasNewDate {
			readNum, _ := db.C("date").Find(bson.M{"isAccept": isAccept, "$or": []bson.M{m1, m2}}).Count()
			db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"hasNewDate": false, "readDate": readNum}})
		}
	} else {
		if user.HasNewRequest {
			readNum, _ := db.C("date").Find(bson.M{"isAccept": isAccept, "$or": []bson.M{m1, m2}}).Count()
			db.C("user").UpdateId(user.Id, bson.M{"$set": bson.M{"hasNewRequest": false, "readRequest": readNum}})
		}
	}
}
