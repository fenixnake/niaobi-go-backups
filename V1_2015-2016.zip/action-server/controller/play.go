package controller

// import (
// 	"action_server/config"
// 	"action_server/errs"
// 	"action_server/model"
// 	"action_server/uid"
// 	"fmt"
// 	"github.com/daddye/vips"
// 	"github.com/go-martini/martini"
// 	"github.com/martini-contrib/render"
// 	"gopkg.in/mgo.v2"
// 	"gopkg.in/mgo.v2/bson"
// 	"io/ioutil"
// 	"net/http"
// 	"os"
// 	"strconv"
// 	"time"
// )

// const (
// 	PlayListPageNum = 15
// )

// const (
// 	PlayMaxPhoto = 5 * 1024 * 1024 //上传最大5MB
// 	PlayPhoto960 = "960x960"       //缩略图 e.g. http://localhost:3000/play/89d171a133a91a88c2f2b6db4c5ef27c_960x960.jpg
// 	PlayPhoto750 = "750x750"
// )

// func PlayPhoto(res http.ResponseWriter, req *http.Request, r render.Render, db *mgo.Database) {
// 	photoId := uid.Uid()

// 	if err := req.ParseMultipartForm(PlayMaxPhoto); err != nil {
// 		errs.Check400(res, err, errs.E1004)
// 	}

// 	playDir := fmt.Sprintf("%s/%s", config.PlayDir, photoId)
// 	path := fmt.Sprintf("%s.jpg", playDir)
// 	toPath750 := fmt.Sprintf("%s_%s.jpg", playDir, PlayPhoto750)
// 	toPath960 := fmt.Sprintf("%s_%s.jpg", playDir, PlayPhoto960)

// 	for _, fileHeaders := range req.MultipartForm.File {
// 		for _, fileHeader := range fileHeaders {
// 			// original image
// 			file, err := fileHeader.Open()
// 			errs.Check400(res, err, errs.E1000)
// 			inBuf, err := ioutil.ReadAll(file)
// 			errs.Check400(res, err, errs.E1000)
// 			err = ioutil.WriteFile(path, inBuf, os.ModePerm)
// 			errs.Check400(res, err, errs.E1000)

// 			// thumbnail 750x750
// 			options := vips.Options{
// 				Width:        750,
// 				Height:       750,
// 				Crop:         true,
// 				Extend:       vips.EXTEND_WHITE,
// 				Interpolator: vips.BILINEAR,
// 				Gravity:      vips.CENTRE,
// 				Quality:      100,
// 			}
// 			buf, err := vips.Resize(inBuf, options)
// 			errs.Check400(res, err, errs.E1000)
// 			err = ioutil.WriteFile(toPath750, buf, os.ModePerm)
// 			errs.Check400(res, err, errs.E1000)
// 			break
// 		}
// 	}

// 	err := os.Rename(path, toPath960)
// 	errs.Check400(res, err, errs.E1000)

// 	r.JSON(http.StatusCreated, map[string]string{"photoId": photoId})
// }

// func NewPlay(res http.ResponseWriter, user model.User, play model.Play, params martini.Params, r render.Render, db *mgo.Database) {
// 	play.Id = bson.NewObjectId()
// 	owner := model.PlayOwner{}
// 	owner.Id = user.Id
// 	play.Owner = owner
// 	play.CreatedAt = time.Now()

// 	if params["id"] != "" {
// 		play.ScriptId = bson.ObjectIdHex(params["id"])
// 	}

// 	//新建play，插入数据库
// 	err := db.C("play").Insert(play)
// 	errs.Check400(res, err, errs.E1000)

// 	//新建playList 把play插入playList
// 	pl := model.PlayList{}
// 	pl.Id = bson.NewObjectId()
// 	pl.PlayId = play.Id
// 	pl.GoneTime = play.GoneTime
// 	pl.CreatedAt = play.CreatedAt
// 	err = db.C("playList").Insert(pl)
// 	errs.Check400(res, err, errs.E1000)

// 	r.JSON(http.StatusCreated, play)
// }

// func PlayList(res http.ResponseWriter, params martini.Params, r render.Render, db *mgo.Database) {
// 	skip, _ := strconv.Atoi(params["skip"])

// 	playList := []model.PlayList{}
// 	newPlayList := []model.PlayList{}

// 	err := db.C("playList").Find(bson.M{"goneTime": bson.M{"$gt": time.Now().Unix()}}).Skip(skip).Limit(PlayListPageNum).Sort("-createdAt").All(&playList)
// 	errs.Check400(res, err, errs.E1000)
// 	for _, p := range playList {
// 		if bson.IsObjectIdHex(p.PlayId.Hex()) {
// 			//play
// 			play := model.Play{}
// 			err := db.C("play").FindId(p.PlayId).One(&play)
// 			if err != nil {
// 				continue
// 			}

// 			u := model.User{}
// 			err = db.C("user").FindId(play.Owner.Id).Select(bson.M{"avatar": 1, "role": 1}).One(&u)
// 			if err != nil {
// 				continue
// 			}
// 			play.Owner.Avatar = u.Avatar
// 			play.Owner.Role = u.Role
// 			p.PlayOrVlogItem = map[string]interface{}{
// 				"play": play,
// 			}
// 			newPlayList = append(newPlayList, p)
// 		} else {
// 			//vlog
// 			vlog := model.Vlog{}
// 			err := db.C("vlog").FindId(p.VlogId).One(&vlog)
// 			if err != nil {
// 				continue
// 			}

// 			u := model.User{}
// 			err = db.C("user").FindId(vlog.Owner.Id).Select(bson.M{"avatar": 1, "role": 1}).One(&u)
// 			if err != nil {
// 				continue
// 			}
// 			vlog.Owner.Avatar = u.Avatar
// 			vlog.Owner.Role = u.Role
// 			p.PlayOrVlogItem = map[string]interface{}{
// 				"vlog": vlog,
// 			}
// 			newPlayList = append(newPlayList, p)
// 		}
// 	}

// 	returnSkip := skip + PlayListPageNum
// 	if len(newPlayList) < PlayListPageNum {
// 		returnSkip = -1
// 	}

// 	pl := model.PlayListJson{}
// 	pl.List = newPlayList
// 	pl.Skip = returnSkip

// 	r.JSON(http.StatusOK, pl)
// }
