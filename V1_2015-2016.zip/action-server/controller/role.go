package controller

import (
	"action_server/config"
	"action_server/errs"
	"action_server/model"
	"action_server/uid"
	"fmt"
	"github.com/daddye/vips"
	"github.com/go-martini/martini"
	"github.com/martini-contrib/render"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io/ioutil"
	"net/http"
	"os"
	"time"
)

const (
	UserMaxRoleNum      = 64               //用户最多能创建64个角色
	MaxRoleImg          = 10 * 1024 * 1024 //上传角色图片最大10MB
	RoleImgName750x1000 = "750x1000"       //角色图片缩略图 e.g. http://localhost:3000/role/89d171a133a91a88c2f2b6db4c5ef27c_750x1000.jpg
	RoleImgW750         = 750
	RoleImgH1000        = 1000
	RoleImgQuality      = 100
)

func NewRole(res http.ResponseWriter, req *http.Request, user model.User, roleFrom model.RoleFrom, r render.Render, db *mgo.Database) {
	count, _ := db.C("role").Find(bson.M{"uid": bson.ObjectIdHex(user.Id.Hex())}).Count()
	if count >= UserMaxRoleNum {
		http.Error(res, errs.E1007, http.StatusBadRequest)
		return
	}

	role := model.Role{}
	role.Id = bson.NewObjectId()
	role.UserId = user.Id
	role.CreatedAt = time.Now()
	role.Image = uid.Uid()
	role.Name = roleFrom.Name
	role.Desc = roleFrom.Desc

	//图片大小监测
	if err := req.ParseMultipartForm(MaxRoleImg); err != nil {
		errs.Check400(res, err, errs.E1004)
	}

	path := fmt.Sprintf("%s/%s.jpg", config.RoleDir, role.Image)
	toPath := fmt.Sprintf("%s/%s_%s.jpg", config.RoleDir, role.Image, RoleImgName750x1000)

	//接收图片
	file, err := roleFrom.Image.Open()
	errs.Check400(res, err, errs.E1000)
	inBuf, err := ioutil.ReadAll(file)
	errs.Check400(res, err, errs.E1000)
	err = ioutil.WriteFile(path, inBuf, os.ModePerm)
	errs.Check400(res, err, errs.E1000)
	//缩略图
	options := vips.Options{
		Width:        RoleImgW750,
		Height:       RoleImgH1000,
		Crop:         true,
		Extend:       vips.EXTEND_WHITE,
		Interpolator: vips.BILINEAR,
		Gravity:      vips.CENTRE,
		Quality:      RoleImgQuality,
	}
	buf, err := vips.Resize(inBuf, options)
	errs.Check400(res, err, errs.E1000)
	err = ioutil.WriteFile(toPath, buf, os.ModePerm)
	errs.Check400(res, err, errs.E1000)

	//新建role，插入数据库
	err = db.C("role").Insert(role)
	errs.Check400(res, err, errs.E1000)

	r.JSON(http.StatusCreated, role)
}

func RoleList(res http.ResponseWriter, user model.User, r render.Render, db *mgo.Database) {
	roleList := []model.Role{}
	err := db.C("role").Find(bson.M{"uid": user.Id}).Sort("-createdAt").All(&roleList)
	errs.Check400(res, err, errs.E1000)

	r.JSON(http.StatusOK, roleList)
}

func DeleteRole(res http.ResponseWriter, user model.User, params martini.Params, r render.Render, db *mgo.Database) {
	role := model.Role{}
	err := db.C("role").Find(bson.M{"_id": bson.ObjectIdHex(params["id"])}).One(&role)
	errs.Check400(res, err, err.Error())

	if role.UserId == user.Id {
		err := db.C("role").RemoveId(role.Id)
		errs.Check400(res, err, errs.E1003)
	}

	res.WriteHeader(http.StatusOK)
}
