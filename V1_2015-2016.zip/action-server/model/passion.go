package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type PassionOwner struct {
	Id     bson.ObjectId `json:"id" bson:"_id"`
	Role   string        `json:"role" bson:"-"`
	Avatar string        `json:"avatar" bson:"-"`
}

//剧本
type Passion struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	Owner     PassionOwner  `json:"owner" bson:"owner"`         //作者
	Script    string        `json:"script" bson:"script"`       //剧本内容
	Type      string        `json:"type" bson:"type"`           //剧情类型 喜剧/爱情..
	Photo     string        `json:"photo" bson:"photo"`         //图片
	PRole     string        `json:"pRole" bson:"pRole"`         //搭档的角色
	PRoleDesc string        `json:"pRoleDesc" bson:"pRoleDesc"` //搭档角色描述
	Likes     int64         `json:"likes" bson:"likes"`         //喜欢数
	Views     int64         `json:"views" bson:"views"`         //查看数
	UpdateAt  int64         `json:"updateAt" bson:"updateAt"`   //更新时间
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`
}

//剧本列表
type PassionList struct {
	List []Passion `json:"list"`
	Skip int       `json:"skip"`
}

//喜欢的剧本
type Likes struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	ScriptId  bson.ObjectId `json:"sid" bson:"sid"` //剧本id
	UserId    bson.ObjectId `json:"uid" bson:"uid"` //用户id
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`

	Script Passion `json:"script" bson:"-"`
}

//剧本列表
type PassionLikeList struct {
	List []Likes `json:"list"`
	Skip int     `json:"skip"`
}
