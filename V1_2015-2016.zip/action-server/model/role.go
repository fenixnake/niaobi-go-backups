package model

import (
	"gopkg.in/mgo.v2/bson"
	"mime/multipart"
	"time"
)

//自己的角色
type Role struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	UserId    bson.ObjectId `json:"uid" bson:"uid"`
	Name      string        `json:"name" bson:"name"`
	Image     string        `json:"image" bson:"image"`
	Desc      string        `json:"desc" bson:"desc"`
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`
}

//新角色上传
type RoleFrom struct {
	Name  string                `form:"name"`
	Desc  string                `form:"desc"`
	Image *multipart.FileHeader `form:"image"`
}
