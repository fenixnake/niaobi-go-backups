package model

import (
	"gopkg.in/mgo.v2/bson"
	"mime/multipart"
	"time"
)

type VlogOwner struct {
	Id     bson.ObjectId `json:"id,omitempty" bson:"_id"`
	Role   string        `json:"role,omitempty" bson:"-"`
	Avatar string        `json:"avatar,omitempty" bson:"-"`
}

type Vlog struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	Owner     VlogOwner     `json:"owner,omitempty" bson:"owner"`
	ScriptId  bson.ObjectId `json:"sid,omitempty" bson:"sid,omitempty"` //剧本Id
	Script    string        `json:"script,omitempty" bson:"script"`     //一句话剧本
	Thumb     string        `json:"thumb,omitempty" bson:"thumb"`       //截图
	FileId    string        `json:"fileId,omitempty" bson:"fileId"`     //视频后端id
	Views     int64         `json:"views,omitempty" bson:"views"`       //观看次数
	Length    int64         `json:"length,omitempty" bson:"length"`     //片长
	Showed    bool          `json:"-" bson:"showed"`                    //是否已上映
	CreatedAt time.Time     `json:"createdAt,omitempty" bson:"createdAt"`
}

type FilmList struct {
	List []Vlog `json:"list"`
	Skip int    `json:"skip"`
}

type Draft struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	FileId    string        `json:"fileId" bson:"fileId"` //视频文件名
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`
}

//-----------上传相关---------------
type ResumableLock struct {
	Locks map[string]bool
}

type VlogChunk struct {
	VideoChunk *multipart.FileHeader `form:"videoChunk"`
	AudioChunk *multipart.FileHeader `form:"audioChunk"`
}

type VlogHeader struct {
	Header *multipart.FileHeader `form:"header"`
	Thumb  *multipart.FileHeader `form:"thumb"`
	Script string                `form:"script"`
	Length int64                 `form:"length"`
}

type VlogInfo struct {
	VideoOffset int64  `json:"videoOffset" form:"videoOffset"`
	AudioOffset int64  `json:"audioOffset" form:"audioOffset"`
	FileName    string `json:"fileName" form:"fileName"`
	IsVideoDone bool   `json:"isVideoDone"`
	IsAudioDone bool   `json:"isAudioDone"`
}

//-----------文件存储---------------
type FileInfo struct {
	Id       string `json:"id"`
	Offset   int64  `json:"offset"`
	FileName string `json:"fileName"`
	FileType string `json:"fileType"`
	Succeed  bool   `json:"succeed"`
}
