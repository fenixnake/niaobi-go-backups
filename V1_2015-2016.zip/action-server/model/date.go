package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type DateOwner struct {
	Id      bson.ObjectId `json:"id" bson:"_id"`
	Phone   string        `json:"phone" bson:"-"`
	PhoneCC string        `json:"phoneCC" bson:"-"`
	Role    string        `json:"role" bson:"-"`
	Avatar  string        `json:"avatar" bson:"-"`
}

type Sender struct {
	Id      bson.ObjectId `json:"id" bson:"_id"`
	Phone   string        `json:"phone" bson:"-"`
	PhoneCC string        `json:"phoneCC" bson:"-"`
	Avatar  string        `json:"avatar" bson:"-"`
	Role    string        `json:"role" bson:"-"`
}

//面基
type Date struct {
	Id         bson.ObjectId `json:"id" bson:"_id"`
	ScriptId   bson.ObjectId `json:"sid" bson:"sid"`               //剧本Id
	Owner      DateOwner     `json:"owner" bson:"owner"`           //贴主
	Sender     Sender        `json:"sender" bson:"sender"`         //搭档
	SenderAddr string        `json:"senderAddr" bson:"senderAddr"` //搭档所在地点
	Note       string        `json:"note" bson:"note"`             //备注
	Photo      string        `json:"photo" bson:"photo"`           //自拍
	IsAccept   bool          `json:"isAccept" bson:"isAccept"`     //是否接受了请求
	IsDelete   bool          `json:"-" bson:"isDelete"`            //帖子不物理删除
	CreatedAt  time.Time     `json:"createdAt" bson:"createdAt"`
}

type DateList struct {
	List []Date `json:"list"`
	Skip int    `json:"skip"`
}
