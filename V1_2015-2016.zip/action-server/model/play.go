package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type PlayOwner struct {
	Id     bson.ObjectId `json:"id,omitempty" bson:"_id"`
	Role   string        `json:"role,omitempty" bson:"-"`
	Avatar string        `json:"avatar,omitempty" bson:"-"`
}

type Play struct {
	Id        bson.ObjectId `json:"id,omitempty" bson:"_id"`
	Owner     PlayOwner     `json:"owner,omitempty" bson:"owner"`   //发布者Id
	ScriptId  bson.ObjectId `json:"sid,omitempty" bson:"sid"`       //剧本Id
	VlogId    bson.ObjectId `json:"vid,omitempty" bson:"vid"`       //VlogId
	Script    string        `json:"script,omitempty" bson:"script"` //一句话剧情
	Photo     string        `json:"photo,omitempty" bson:"photo"`   //封面
	UpdateAt  int64         `json:"updateAt,omitempty" bson:"updateAt"`
	CreatedAt time.Time     `json:"createdAt,omitempty" bson:"createdAt"`
}

type PlayList struct {
	List []PlayList `json:"list"`
	Skip int        `json:"skip"`
}
