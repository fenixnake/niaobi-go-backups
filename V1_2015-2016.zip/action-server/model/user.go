package model

import (
	"gopkg.in/mgo.v2/bson"
	"time"
)

type RegisterDoneForm struct {
	Role  string `json:"role"`
	Email string `json:"email"`
}

type User struct {
	Id        bson.ObjectId `json:"id" bson:"_id"`
	PhoneCC   string        `json:"phoneCC" bson:"phoneCC" binding:"required"` //必填
	Phone     string        `json:"phone" bson:"phone" binding:"required"`     //必填，手机号不可重复，索引
	Pwd       string        `json:"pwd" bson:"pwd" binding:"required"`         //必填，索引
	Name      string        `json:"name" bson:"name"`                          //昵称默认注册日期，不可重复
	Role      string        `json:"role" bson:"role"`                          //默认角色
	Avatar    string        `json:"avatar" bson:"avatar"`                      //头像
	Bio       string        `json:"bio" bson:"bio"`                            //喜欢的世界观
	Email     string        `json:"email" bson:"email"`                        //密码找回邮箱
	Sex       int           `json:"sex" bson:"sex"`                            //生理性别
	Likes     int           `json:"likes" bson:"likes"`                        //喜欢的剧情数量
	OpenType  []string      `json:"openType" bson:"openType"`                  //欢迎什么类型的人勾搭
	CreatedAt time.Time     `json:"createdAt" bson:"createdAt"`

	HasNewDate    bool `json:"hasNewDate" bson:"hasNewDate"`       //是否有未读的面基
	ReadDate      int  `json:"readDate" bson:"readDate"`           //已读的面基数
	HasNewRequest bool `json:"hasNewRequest" bson:"hasNewRequest"` //是否有未读的面基请求
	ReadRequest   int  `json:"readRequest" bson:"readRequest"`     //已读的面基请求数

	DeviceToken string `json:"diviceToken" bson:"diviceToken"`
}

type MyProfile struct {
	User          User `json:"user"`
	UnReadDate    int  `json:"unReadDate"`    //未读日程数
	UnReadRequest int  `json:"unReadRequest"` //未读请求数
}
