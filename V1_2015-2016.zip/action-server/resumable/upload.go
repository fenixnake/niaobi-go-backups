package resumable

import (
	"action_server/config"
	"action_server/model"
	"encoding/json"
	"io"
	"io/ioutil"
	"os"
)

var defaultFilePerm = os.FileMode(0775)

func NewUpload(info model.FileInfo) (err error) {
	// Create .bin file with no content
	file, err := os.OpenFile(getBinPath(info.Id), os.O_CREATE|os.O_WRONLY, defaultFilePerm)
	if err != nil {
		return
	}
	defer file.Close()

	// writeInfo creates the file by itself if necessary
	err = writeInfo(info.Id, info)
	return err
}

func WriteChunk(id string, offset int64, src io.Reader) (int64, error) {
	file, err := os.OpenFile(getBinPath(id), os.O_WRONLY|os.O_APPEND, defaultFilePerm)
	if err != nil {
		return 0, err
	}
	defer file.Close()

	n, err := io.Copy(file, src)
	if n > 0 {
		if err := setOffset(id, offset+n); err != nil {
			return 0, err
		}
	}
	return n, err
}

func WriteHeader(id string, src io.Reader) error {
	file, err := os.OpenFile(getBinPath(id), os.O_WRONLY, defaultFilePerm)
	if err != nil {
		return err
	}
	defer file.Close()

	header, err := ioutil.ReadAll(src)
	_, err = file.WriteAt(header, 0)
	if err != nil {
		return err
	}

	info, err := GetInfo(id)
	if err != nil {
		return err
	}

	info.Succeed = true

	err = writeInfo(id, info)
	return err
}

func GetInfo(id string) (model.FileInfo, error) {
	info := model.FileInfo{}
	data, err := ioutil.ReadFile(getInfoPath(id))
	if err != nil {
		return info, err
	}
	err = json.Unmarshal(data, &info)
	return info, err
}

// Return the path to the .bin storing the binary data
func getBinPath(id string) string {
	return config.DataDir + "/" + id + ".bin"
}

// Return the path to the .info file storing the file's info
func getInfoPath(id string) string {
	return config.DataDir + "/" + id + ".info"
}

// Update the entire information. Everything will be overwritten.
func writeInfo(id string, info model.FileInfo) error {
	data, err := json.Marshal(info)
	if err != nil {
		return err
	}
	return ioutil.WriteFile(getInfoPath(id), data, defaultFilePerm)
}

// Update the .info file using the new upload.
func setOffset(id string, offset int64) error {
	info, err := GetInfo(id)
	if err != nil {
		return err
	}

	// never decrement the offset
	if info.Offset >= offset {
		return nil
	}

	info.Offset = offset
	return writeInfo(id, info)
}
