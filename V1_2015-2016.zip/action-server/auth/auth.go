package auth

import (
	"action_server/errs"
	"action_server/model"
	"encoding/base64"
	"fmt"
	"github.com/go-martini/martini"
	"gopkg.in/mgo.v2/bson"
	"net/http"
	"strings"
)

func BasicFunc(authfn func(string, string) model.User) martini.Handler {
	return func(res http.ResponseWriter, req *http.Request, c martini.Context) {
		auth := req.Header.Get("Authorization")
		if len(auth) < 6 || auth[:6] != "Basic " {
			fmt.Println("auth err1")
			unauthorized(res)
		}
		b, err := base64.StdEncoding.DecodeString(auth[6:])
		if err != nil {
			fmt.Println("auth err2")
			unauthorized(res)
		}
		tokens := strings.SplitN(string(b), ":", 2)
		if len(tokens) != 2 {
			fmt.Println("auth err3")
			unauthorized(res)
		}
		user := authfn(tokens[0], tokens[1])
		if !bson.IsObjectIdHex(user.Id.Hex()) {
			fmt.Println("auth err4")
			unauthorized(res)
		}
		c.Map(user)
	}
}

func unauthorized(res http.ResponseWriter) {
	http.Error(res, errs.E1003, http.StatusUnauthorized)
	return
}
