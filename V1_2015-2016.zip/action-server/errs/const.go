package errs

const (
	E1000 = "server error"
	E1001 = "invalid phone number"
	E1002 = "phone already exists"
	E1003 = "not authorized"
	E1004 = "image file size too big"
	E1005 = "phone does not exist"
	E1006 = "invalid password"
	E1007 = "role max count is 64"
	E1008 = "script already liked"

	E2000 = "video upload error"
	E2001 = "upload not found"
	E2002 = "maximum size exceeded"
	E2003 = "file currently locked"
	E2004 = "illegal offset"
	E2005 = "video already exists"
)
