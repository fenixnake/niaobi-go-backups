package errs

import (
	"log"
	"net/http"
)

func Check400(res http.ResponseWriter, err error, msg string) {
	if err != nil {
		http.Error(res, msg, http.StatusBadRequest)
		log.Println("[action]->err:", err.Error())
		return
	}
}
