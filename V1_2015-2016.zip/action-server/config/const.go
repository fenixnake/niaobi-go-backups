package config

const (
	MongoDBAddr   = "mongodb://127.0.0.1"
	MongoDBName   = "action"
	StaticDir     = "files"
	DataDir       = "./" + StaticDir + "/data"
	PassionDir    = "./" + StaticDir + "/passion"
	DateDir       = "./" + StaticDir + "/date"
	AvatarDir     = "./" + StaticDir + "/avatar"
	RoleDir       = "./" + StaticDir + "/role"
	MaxChunkSize  = 64 * 1024 //视频+音频
	MaxHeaderSize = 128
)
